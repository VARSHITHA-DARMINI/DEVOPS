const express = require("express");
const router = express.Router();
const Product = require("../models/Product");


// CREATE PRODUCT
router.post("/", async (req, res) => {
    try {
        const product = await Product.create(req.body);

        res.status(201).json({
            success: true,
            message: "Product created successfully",
            data: product
        });

    } catch (error) {
        res.status(400).json({
            success: false,
            message: "Failed to create product",
            error: error.errors
                ? error.errors.map(err => err.message)
                : error.message
        });
    }
});


// GET ALL PRODUCTS
router.get("/", async (req, res) => {
    try {
        const products = await Product.findAll({
            order: [["productId", "ASC"]]
        });

        res.status(200).json({
            success: true,
            message: "Products retrieved successfully",
            count: products.length,
            data: products
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to retrieve products",
            error: error.message
        });
    }
});


// SEARCH BY CATEGORY
router.get("/search/category", async (req, res) => {
    try {
        const { category } = req.query;

        if (!category) {
            return res.status(400).json({
                success: false,
                message: "Category query parameter is required"
            });
        }

        const products = await Product.findAll({
            where: {
                category: category
            },
            order: [["productId", "ASC"]]
        });

        res.status(200).json({
            success: true,
            message: "Products found successfully",
            count: products.length,
            data: products
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Category search failed",
            error: error.message
        });
    }
});


// SORT BY PRICE
router.get("/sort/price", async (req, res) => {
    try {
        const order =
            req.query.order === "desc" ? "DESC" : "ASC";

        const products = await Product.findAll({
            order: [["price", order]]
        });

        res.status(200).json({
            success: true,
            message: `Products sorted by price (${order})`,
            data: products
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Price sorting failed",
            error: error.message
        });
    }
});


// GET PRODUCT BY ID
router.get("/:id", async (req, res) => {
    try {
        const product = await Product.findByPk(req.params.id);

        if (!product) {
            return res.status(404).json({
                success: false,
                message: "Product not found"
            });
        }

        res.status(200).json({
            success: true,
            message: "Product retrieved successfully",
            data: product
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to retrieve product",
            error: error.message
        });
    }
});


// UPDATE PRODUCT
router.put("/:id", async (req, res) => {
    try {
        const product = await Product.findByPk(req.params.id);

        if (!product) {
            return res.status(404).json({
                success: false,
                message: "Product not found"
            });
        }

        await product.update(req.body);

        res.status(200).json({
            success: true,
            message: "Product updated successfully",
            data: product
        });

    } catch (error) {
        res.status(400).json({
            success: false,
            message: "Failed to update product",
            error: error.errors
                ? error.errors.map(err => err.message)
                : error.message
        });
    }
});


// DELETE PRODUCT
router.delete("/:id", async (req, res) => {
    try {
        const product = await Product.findByPk(req.params.id);

        if (!product) {
            return res.status(404).json({
                success: false,
                message: "Product not found"
            });
        }

        await product.destroy();

        res.status(200).json({
            success: true,
            message: "Product deleted successfully"
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Failed to delete product",
            error: error.message
        });
    }
});


module.exports = router;