const express = require("express");
const sequelize = require("./config/database");
const productRoutes = require("./routes/productRoutes");

const app = express();


// Middleware
app.use(express.json());


// Home route
app.get("/", (req, res) => {
    res.json({
        success: true,
        message: "Online Shopping Product API is running"
    });
});


// Product routes
app.use("/api/products", productRoutes);


const PORT = process.env.PORT || 3000;


// Start server
async function startServer() {
    try {

        await sequelize.authenticate();

        console.log("PostgreSQL database connected successfully.");

        await sequelize.sync();

        console.log("Product table created using Sequelize.");

        app.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}`);
        });

    } catch (error) {

        console.error(
            "Database connection failed:",
            error.message
        );
    }
}

startServer();