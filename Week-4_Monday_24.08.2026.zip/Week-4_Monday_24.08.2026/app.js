const express = require("express");
const sequelize = require("./config/database");
const bookRoutes = require("./routes/bookRoutes");

const app = express();


// Middleware
app.use(express.json());


// Routes
app.use("/books", bookRoutes);


// Start server
async function startServer() {
  try {
    // Test database connection
    await sequelize.authenticate();

    console.log("Database connected successfully.");

    // Synchronize Sequelize model with PostgreSQL
    await sequelize.sync({ alter: true });

    console.log("Books table synchronized successfully.");

    const PORT = 3000;

    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

  } catch (error) {
    console.error("Unable to start the application:");
    console.error(error.message);
  }
}


startServer();