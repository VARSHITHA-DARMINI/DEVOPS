const { Op } = require("sequelize");
const Book = require("../models/Book");


// CREATE - Add a new book
const createBook = async (req, res) => {
  try {
    const {
      title,
      author,
      isbn,
      price,
      availableCopies
    } = req.body;

    // Required field validation
    if (
      !title ||
      !author ||
      !isbn ||
      price === undefined ||
      availableCopies === undefined
    ) {
      return res.status(400).json({
        message:
          "Title, author, ISBN, price, and available copies are required."
      });
    }

    // Price validation
    if (Number(price) < 0) {
      return res.status(400).json({
        message: "Price cannot be negative."
      });
    }

    // Available copies validation
    if (
      !Number.isInteger(Number(availableCopies)) ||
      Number(availableCopies) < 0
    ) {
      return res.status(400).json({
        message: "Available copies must be a non-negative integer."
      });
    }

    // ISBN uniqueness validation
    const existingBook = await Book.findOne({
      where: { isbn }
    });

    if (existingBook) {
      return res.status(409).json({
        message: "A book with this ISBN already exists."
      });
    }

    const book = await Book.create({
      title,
      author,
      isbn,
      price,
      availableCopies
    });

    return res.status(201).json({
      message: "Book created successfully.",
      book
    });

  } catch (error) {
    console.error("Create book error:", error);

    return res.status(500).json({
      message: "Failed to create book.",
      error: error.message
    });
  }
};


// READ - Get all books
const getAllBooks = async (req, res) => {
  try {
    const books = await Book.findAll({
      order: [["id", "ASC"]]
    });

    return res.status(200).json(books);

  } catch (error) {
    console.error("Get all books error:", error);

    return res.status(500).json({
      message: "Failed to retrieve books.",
      error: error.message
    });
  }
};


// READ - Get one book by ID
const getBookById = async (req, res) => {
  try {
    const id = req.params.id;

    const book = await Book.findByPk(id);

    if (!book) {
      return res.status(404).json({
        message: "Book not found."
      });
    }

    return res.status(200).json(book);

  } catch (error) {
    console.error("Get book by ID error:", error);

    return res.status(500).json({
      message: "Failed to retrieve book.",
      error: error.message
    });
  }
};


// UPDATE - Update a book
const updateBook = async (req, res) => {
  try {
    const id = req.params.id;

    const book = await Book.findByPk(id);

    if (!book) {
      return res.status(404).json({
        message: "Book not found."
      });
    }

    const {
      title,
      author,
      isbn,
      price,
      availableCopies
    } = req.body;

    // Check ISBN uniqueness if ISBN is changed
    if (isbn && isbn !== book.isbn) {
      const existingBook = await Book.findOne({
        where: {
          isbn,
          id: {
            [Op.ne]: id
          }
        }
      });

      if (existingBook) {
        return res.status(409).json({
          message: "A book with this ISBN already exists."
        });
      }
    }

    // Validate price
    if (price !== undefined && Number(price) < 0) {
      return res.status(400).json({
        message: "Price cannot be negative."
      });
    }

    // Validate available copies
    if (
      availableCopies !== undefined &&
      (
        !Number.isInteger(Number(availableCopies)) ||
        Number(availableCopies) < 0
      )
    ) {
      return res.status(400).json({
        message: "Available copies must be a non-negative integer."
      });
    }

    await book.update({
      title: title !== undefined ? title : book.title,
      author: author !== undefined ? author : book.author,
      isbn: isbn !== undefined ? isbn : book.isbn,
      price: price !== undefined ? price : book.price,
      availableCopies:
        availableCopies !== undefined
          ? availableCopies
          : book.availableCopies
    });

    return res.status(200).json({
      message: "Book updated successfully.",
      book
    });

  } catch (error) {
    console.error("Update book error:", error);

    return res.status(500).json({
      message: "Failed to update book.",
      error: error.message
    });
  }
};


// DELETE - Delete a book
const deleteBook = async (req, res) => {
  try {
    const id = req.params.id;

    const book = await Book.findByPk(id);

    if (!book) {
      return res.status(404).json({
        message: "Book not found."
      });
    }

    await book.destroy();

    return res.status(200).json({
      message: "Book deleted successfully."
    });

  } catch (error) {
    console.error("Delete book error:", error);

    return res.status(500).json({
      message: "Failed to delete book.",
      error: error.message
    });
  }
};


// BONUS - Search by author,
// filter by availability,
// sort alphabetically by title
const searchBooks = async (req, res) => {
  try {
    const { author, available, sort } = req.query;

    const where = {};

    // Search by author
    if (author) {
      where.author = {
        [Op.iLike]: `%${author}%`
      };
    }

    // Filter by availability
    if (available !== undefined) {
      if (available === "true") {
        where.availableCopies = {
          [Op.gt]: 0
        };
      } else if (available === "false") {
        where.availableCopies = 0;
      } else {
        return res.status(400).json({
          message: "Available must be true or false."
        });
      }
    }

    // Sort alphabetically by title
    let order = [["id", "ASC"]];

    if (sort === "title") {
      order = [["title", "ASC"]];
    }

    const books = await Book.findAll({
      where,
      order
    });

    return res.status(200).json(books);

  } catch (error) {
    console.error("Search books error:", error);

    return res.status(500).json({
      message: "Failed to search/filter books.",
      error: error.message
    });
  }
};


module.exports = {
  createBook,
  getAllBooks,
  getBookById,
  updateBook,
  deleteBook,
  searchBooks
};