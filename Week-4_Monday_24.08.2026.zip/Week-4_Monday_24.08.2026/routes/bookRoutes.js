const express = require("express");

const {
  createBook,
  getAllBooks,
  getBookById,
  updateBook,
  deleteBook,
  searchBooks
} = require("../controllers/bookController");

const router = express.Router();


// CREATE
router.post("/", createBook);


// READ - all books
router.get("/", getAllBooks);


// BONUS - search/filter/sort
// This must come BEFORE /:id
router.get("/search", searchBooks);


// READ - one book
router.get("/:id", getBookById);


// UPDATE
router.put("/:id", updateBook);


// DELETE
router.delete("/:id", deleteBook);


module.exports = router;