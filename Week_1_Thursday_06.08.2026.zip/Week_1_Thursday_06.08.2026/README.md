# Library Management System

## LAB PRACTICAL-01

A Library Management System developed using Git workflow and version control.

## Features

### Book Management
- Add books
- Update books
- Search books
- Remove books

### Member Management
- Register members
- Update members
- Search members
- Remove members

## Git Branches

- main - Stable release
- feature-books - Book management
- feature-members - Member management

## Release

v1.0-library