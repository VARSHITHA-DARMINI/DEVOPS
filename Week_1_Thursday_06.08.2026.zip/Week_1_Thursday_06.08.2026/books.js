// Library Management System
// Book Management Module

let books = [];

// Add a book
function addBook(id, title, author) {
    const book = {
        id,
        title,
        author
    };

    books.push(book);
    console.log("Book added successfully:", book);
}

// Update a book
function updateBook(id, newTitle, newAuthor) {
    const book = books.find(book => book.id === id);

    if (book) {
        book.title = newTitle;
        book.author = newAuthor;
        console.log("Book updated successfully:", book);
    } else {
        console.log("Book not found.");
    }
}

// Search for a book
function searchBook(title) {
    const results = books.filter(book =>
        book.title.toLowerCase().includes(title.toLowerCase())
    );

    console.log("Search results:", results);
}

// Remove a book
function removeBook(id) {
    const index = books.findIndex(book => book.id === id);

    if (index !== -1) {
        const removedBook = books.splice(index, 1);
        console.log("Book removed successfully:", removedBook[0]);
    } else {
        console.log("Book not found.");
    }
}

// Sample book records
addBook(1, "The Alchemist", "Paulo Coelho");
addBook(2, "Wings of Fire", "A.P.J. Abdul Kalam");
addBook(3, "Clean Code", "Robert C. Martin");

console.log("\nAll Books:");
console.log(books);

// Search
searchBook("Wings");

// Update
updateBook(1, "The Alchemist - Updated", "Paulo Coelho");

// Remove
removeBook(3);

console.log("\nFinal Book List:");
console.log(books);