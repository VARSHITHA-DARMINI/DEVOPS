// Library Management System
// Member Management Module

let members = [];

// Register a member
function registerMember(id, name, email) {
    const member = {
        id,
        name,
        email
    };

    members.push(member);
    console.log("Member registered successfully:", member);
}

// Update member information
function updateMember(id, newName, newEmail) {
    const member = members.find(member => member.id === id);

    if (member) {
        member.name = newName;
        member.email = newEmail;
        console.log("Member updated successfully:", member);
    } else {
        console.log("Member not found.");
    }
}

// Search for a member
function searchMember(name) {
    const results = members.filter(member =>
        member.name.toLowerCase().includes(name.toLowerCase())
    );

    console.log("Member search results:", results);
}

// Remove a member
function removeMember(id) {
    const index = members.findIndex(member => member.id === id);

    if (index !== -1) {
        const removedMember = members.splice(index, 1);
        console.log("Member removed successfully:", removedMember[0]);
    } else {
        console.log("Member not found.");
    }
}

// Sample member records
registerMember(101, "Varshitha", "varshitha@example.com");
registerMember(102, "Rahul", "rahul@example.com");
registerMember(103, "Anjali", "anjali@example.com");

console.log("\nAll Members:");
console.log(members);

// Search
searchMember("Rahul");

// Update
updateMember(
    101,
    "Varshitha Darmini",
    "varshitha.darmini@example.com"
);

// Remove
removeMember(103);

console.log("\nFinal Member List:");
console.log(members);