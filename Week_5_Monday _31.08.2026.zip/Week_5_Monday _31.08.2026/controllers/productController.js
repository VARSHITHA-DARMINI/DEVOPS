const Product = require("../models/Product");

// Create a new product
const createProduct = async (req, res) => {
  try {
    const product = await Product.create(req.body);

    res.status(201).json({
      success: true,
      message: "Product created successfully.",
      data: product
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: "Product ID already exists."
      });
    }

    res.status(400).json({
      success: false,
      message: "Failed to create product.",
      error: error.message
    });
  }
};

// Get all products
const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find();

    res.status(200).json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to retrieve products.",
      error: error.message
    });
  }
};

// Get product by ID
const getProductById = async (req, res) => {
  try {
    const product = await Product.findOne({
      productId: req.params.id
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found."
      });
    }

    res.status(200).json({
      success: true,
      data: product
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to retrieve product.",
      error: error.message
    });
  }
};

// Update product price
const updateProductPrice = async (req, res) => {
  try {
    const { price } = req.body;

    if (price === undefined) {
      return res.status(400).json({
        success: false,
        message: "Price is required."
      });
    }

    const product = await Product.findOneAndUpdate(
      { productId: req.params.id },
      { price: price },
      { new: true, runValidators: true }
    );

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found."
      });
    }

    res.status(200).json({
      success: true,
      message: "Product price updated successfully.",
      data: product
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: "Failed to update product price.",
      error: error.message
    });
  }
};

// Delete product
const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findOneAndDelete({
      productId: req.params.id
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Product not found."
      });
    }

    res.status(200).json({
      success: true,
      message: "Product deleted successfully.",
      data: product
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to delete product.",
      error: error.message
    });
  }
};

// Search products by category
const searchByCategory = async (req, res) => {
  try {
    const { category } = req.query;

    if (!category) {
      return res.status(400).json({
        success: false,
        message: "Category is required."
      });
    }

    const products = await Product.find({
      category: { $regex: category, $options: "i" }
    });

    res.status(200).json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to search products.",
      error: error.message
    });
  }
};

// Sort products by price
const sortByPrice = async (req, res) => {
  try {
    const order = req.query.order === "desc" ? -1 : 1;

    const products = await Product.find().sort({
      price: order
    });

    res.status(200).json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Failed to sort products.",
      error: error.message
    });
  }
};

module.exports = {
  createProduct,
  getAllProducts,
  getProductById,
  updateProductPrice,
  deleteProduct,
  searchByCategory,
  sortByPrice
};