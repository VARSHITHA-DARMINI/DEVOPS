const express = require("express");

const {
  createProduct,
  getAllProducts,
  getProductById,
  updateProductPrice,
  deleteProduct,
  searchByCategory,
  sortByPrice
} = require("../controllers/productController");

const router = express.Router();

// Create product
router.post("/", createProduct);

// Get all products
router.get("/", getAllProducts);

// Search products by category
router.get("/search", searchByCategory);

// Sort products by price
router.get("/sort", sortByPrice);

// Get product by Product ID
router.get("/:id", getProductById);

// Update product price
router.put("/:id", updateProductPrice);

// Delete product
router.delete("/:id", deleteProduct);

module.exports = router;