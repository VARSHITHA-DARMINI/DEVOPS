const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const {
    createUser,
    findByEmail,
    findById
} = require("../models/userModel");


async function register(req, res) {
    try {
        const {
            name,
            email,
            password,
            role,
            department
        } = req.body;

        if (
            !name ||
            !email ||
            !password ||
            !role ||
            !department
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Name, email, password, role and department are required."
            });
        }

        const validRoles = [
            "student",
            "faculty",
            "admin"
        ];

        if (!validRoles.includes(role)) {
            return res.status(400).json({
                success: false,
                message:
                    "Role must be student, faculty or admin."
            });
        }

        const existingUser = findByEmail(email);

        if (existingUser) {
            return res.status(409).json({
                success: false,
                message: "Email already registered."
            });
        }

        const user = await createUser({
            name,
            email,
            password,
            role,
            department
        });

        res.status(201).json({
            success: true,
            message: "User registered successfully.",
            user: {
                id: user.id,
                name: user.name,
                email: user.email,
                role: user.role,
                department: user.department
            }
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Server error while registering user."
        });
    }
}


async function login(req, res) {
    try {
        const {
            email,
            password
        } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message:
                    "Email and password are required."
            });
        }

        const user = findByEmail(email);

        if (!user) {
            return res.status(401).json({
                success: false,
                message:
                    "Incorrect email or password."
            });
        }

        const passwordMatch =
            await bcrypt.compare(
                password,
                user.password
            );

        if (!passwordMatch) {
            return res.status(401).json({
                success: false,
                message:
                    "Incorrect email or password."
            });
        }

        const payload = {
            userId: user.id,
            email: user.email,
            role: user.role
        };

        const token = jwt.sign(
            payload,
            process.env.JWT_SECRET,
            {
                expiresIn:
                    process.env.JWT_EXPIRES_IN || "1h"
            }
        );

        res.json({
            success: true,
            message: "Login successful.",
            token: token
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Server error while logging in."
        });
    }
}


function getProfile(req, res) {
    const user = findById(req.user.userId);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: "User not found."
        });
    }

    res.json({
        success: true,
        user: {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
            department: user.department
        }
    });
}


module.exports = {
    register,
    login,
    getProfile
};