const {
    getAllStudents,
    findStudentById,
    updateStudent
} = require("../models/studentModel");


function getStudents(req, res) {

    const students = getAllStudents();

    res.json({
        success: true,
        count: students.length,
        students: students
    });
}


function updateStudentInfo(req, res) {

    const student =
        findStudentById(req.params.id);

    if (!student) {
        return res.status(404).json({
            success: false,
            message: "Student not found."
        });
    }

    const updatedStudent =
        updateStudent(
            req.params.id,
            req.body
        );

    res.json({
        success: true,
        message:
            "Student information updated successfully.",
        student: updatedStudent
    });
}


module.exports = {
    getStudents,
    updateStudentInfo
};