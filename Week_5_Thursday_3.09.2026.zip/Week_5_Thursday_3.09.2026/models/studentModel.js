const students = [
    {
        id: 1,
        name: "Aarav Kumar",
        email: "aarav@example.com",
        department: "CSE",
        year: 3,
        cgpa: 8.7
    },
    {
        id: 2,
        name: "Priya Sharma",
        email: "priya@example.com",
        department: "AI&DS",
        year: 2,
        cgpa: 9.1
    }
];

function getAllStudents() {
    return students;
}

function findStudentById(id) {
    return students.find(
        (student) => student.id === Number(id)
    );
}

function updateStudent(id, updates) {
    const student = findStudentById(id);

    if (!student) {
        return null;
    }

    if (updates.name !== undefined) {
        student.name = updates.name;
    }

    if (updates.email !== undefined) {
        student.email = updates.email;
    }

    if (updates.department !== undefined) {
        student.department = updates.department;
    }

    if (updates.year !== undefined) {
        student.year = updates.year;
    }

    if (updates.cgpa !== undefined) {
        student.cgpa = updates.cgpa;
    }

    return student;
}

module.exports = {
    getAllStudents,
    findStudentById,
    updateStudent
};