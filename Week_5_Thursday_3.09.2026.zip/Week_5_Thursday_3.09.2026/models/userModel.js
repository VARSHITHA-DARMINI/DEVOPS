const bcrypt = require("bcryptjs");

const users = [];

let nextUserId = 1;

async function createUser({ name, email, password, role, department }) {
    const hashedPassword = await bcrypt.hash(password, 10);

    const user = {
        id: nextUserId++,
        name,
        email: email.toLowerCase(),
        password: hashedPassword,
        role,
        department
    };

    users.push(user);

    return user;
}

function findByEmail(email) {
    return users.find(
        (user) => user.email === email.toLowerCase()
    );
}

function findById(id) {
    return users.find(
        (user) => user.id === Number(id)
    );
}

function getAllUsers() {
    return users;
}

module.exports = {
    createUser,
    findByEmail,
    findById,
    getAllUsers
};