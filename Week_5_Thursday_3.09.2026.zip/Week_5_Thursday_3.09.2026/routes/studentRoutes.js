const express = require("express");

const {
    getStudents,
    updateStudentInfo
} = require("../controllers/studentController");

const {
    authenticateToken,
    authorizeRoles
} = require("../middleware/authMiddleware");


const router = express.Router();


router.get(
    "/students",
    authenticateToken,
    authorizeRoles(
        "student",
        "faculty",
        "admin"
    ),
    getStudents
);


router.put(
    "/students/:id",
    authenticateToken,
    authorizeRoles(
        "faculty",
        "admin"
    ),
    updateStudentInfo
);


module.exports = router;